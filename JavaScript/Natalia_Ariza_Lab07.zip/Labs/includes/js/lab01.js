 alert ("Hello World!");
 
 
document.getElementById("hello").innerHTML = "Hello, [name], How many Rooms do you want to book?!";


//Get placeholder element
let helloElement = document.getElementById("hello");

//Prompt the user for their name
let name = prompt("Enter your name:");


helloElement.textContent = "Hello, " + name + ". Nice to meet you again.";

//console.log("testing is OK so far...");


//Get placeholder element
let amountElement = document.getElementById("amount");
let taxRateElement = document.getElementById("taxRate");
let numberRoomsElement = document.getElementById("numberRoom");
let totalAmountElement = document.getElementById("totalAmount");

//Prompt the user for the amount, tax rate and number of rooms
let amount = prompt("Enter the amount:"); // can be something like 125.50
let taxRate = prompt("Enter the tax rate (%):");
let numRooms = prompt("Enter the number of rooms:"); // each of these is a string, need to make them into integers

let amountValue = parseFloat(amount);
let taxRateValue = parseInt(taxRate);
let numRoomsValue = parseInt(numRooms); 


let total = (amountValue + (amountValue * taxRateValue / 100)) * numRoomsValue;

amountElement.innerHTML = "$" + amountValue.toFixed(2);
taxRateElement.innerHTML = taxRateValue + "%";
numberRoomsElement.innerHTML = numRoomsValue;
totalAmountElement.innerHTML = "$" + total.toFixed(2);


