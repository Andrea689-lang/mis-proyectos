// Task 1


let personCard = document.getElementById("person-card");
let greetingMessage = document.getElementById("greeting-message");


let loginButton = document.getElementById("login-button");
let loginItem = document.getElementById("login-item");
let logoutButton = document.getElementById("logout-button");
let logoutItem = document.getElementById("logout-item");


let submitButton = document.getElementById("submit-button");

// to make the button show or hide, set the style attribute of the loginItem/logoutItem to "display:list-item" or "display:none"

logoutButton.onclick = function () {
	/*
	hide the card
	hide the greeting message
	hide the logout button
	show the login button
	*/
	personCard.setAttribute("style","display:none");
	greetingMessage.setAttribute("style","display:none");
	logoutItem.setAttribute("style","display:none");
	loginItem.setAttribute("style","display:list-item");
	
}




submitButton.onclick = function () {
	
	
	let firstNameInput = document.getElementById("firstName-input");
	let lastNameInput = document.getElementById("lastName-input");
	let emailInput = document.getElementById("email-input");
	let ageInput = document.getElementById("age-input");
	let postalCodeInput = document.getElementById("postalCode-input");
	let phoneInput = document.getElementById("phone-input");

	let firstNameMessage = document.getElementById("firstName-message");
	let lastNameMessage = document.getElementById("lastName-message");
	let emailMessage = document.getElementById("email-message");
	let ageMessage = document.getElementById("age-message");
	let postalCodeMessage = document.getElementById("postalCode-message");
	let phoneMessage = document.getElementById("phone-message");
  
  let firstName = firstNameInput.value;
  let lastName = lastNameInput.value;
  let email = emailInput.value;
  let age = ageInput.value;
  let phoneNumber = phoneInput.value;
  let postalCode = postalCodeInput.value;
  
  

	let areErrors = false;
	
	/*
	Name fields - cannot be blank and can not have a space in the name
	Age field - must be a number between 0 and 120
	Email field - must be a valid email which is determined through regular expressions. Input with a type email is not sufficient.
	Phone field - must be in the format of 000-000-0000 or 0000000000 or 000 000 0000
	Postal code field - must be in the format of a Canadian postal code (ANANAN or ANA NAN) where A is an alphabetic character and N is a number, for example V8X 1H8. Look at the Canadian Postal Code rules to find out which letters you can not use.
	*/
  
	// first name: not blank, no spaces
	let firstNameRegex = /^\S*$/; // true if no spaces
	if (firstName == "") {
		firstNameMessage.textContent = "First name can't be blank";
		firstNameMessage.setAttribute("style","color:red;width:100%;");
		areErrors = true;
	} else if (firstNameRegex.test(firstName) == false) {
		firstNameMessage.textContent = "First name can't have spaces";
		firstNameMessage.setAttribute("style","color:red;width:100%;");
		areErrors = true;
	} else {
		firstNameMessage.textContent = "Good first name";
		firstNameMessage.setAttribute("style","color:green;width:100%;");
	}

	// last name: not blank, no spaces
	let lastNameRegex = /^\S*$/; // true if no spaces
	if (lastName == "") {
		lastNameMessage.textContent = "Last name can't be blank";
		lastNameMessage.setAttribute("style","color:red;width:100%;");
		areErrors = true;
	} else if (lastNameRegex.test(lastName) == false) {
		lastNameMessage.textContent = "Last name can't have spaces";
		lastNameMessage.setAttribute("style","color:red;width:100%;");
		areErrors = true;
	} else {
		lastNameMessage.textContent = "Good last name";
		lastNameMessage.setAttribute("style","color:green;width:100%;");
	}
	
	// email: not blank, regex match
	// https://regex101.com/library/mX1xW0
	let emailRegex = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/; // true if good
	if (email == "") {
		emailMessage.textContent = "Email can't be blank";
		emailMessage.setAttribute("style","color:red;width:100%;");
		areErrors = true;
	} else if (emailRegex.test(email) == false) {
		emailMessage.textContent = "Email is not a valid format; try something like test@test.com";
		emailMessage.setAttribute("style","color:red;width:100%;");
		areErrors = true;
	} else {
		emailMessage.textContent = "Good email";
		emailMessage.setAttribute("style","color:green;width:100%;");
	}

	
	// age: not blank, regex match, 0 - 120
	let ageRegex = /^\d+$/;
	if (age == "") {
		ageMessage.textContent = "Age can't be blank";
		ageMessage.setAttribute("style","color:red;width:100%;");
		console.log("age error");
		areErrors = true;
	} else if (ageRegex.test(age) == false) {
		ageMessage.textContent = "Age must be a number";
		ageMessage.setAttribute("style","color:red;width:100%;");
		areErrors = true;
	} else if (parseInt(age,10) < 0 || parseInt(age,10) > 120) {
		ageMessage.textContent = "Age must be be between 0 and 120";
		ageMessage.setAttribute("style","color:red;width:100%;");
		areErrors = true;
	} else {
		ageMessage.textContent = "Good age";
		ageMessage.setAttribute("style","color:green;width:100%;");
	}
	
	// postalCode: not blank, regex match
	// https://regex101.com/library/TqLf63
	let postalCodeRegex = /^[ABCEGHJ-NPRSTVXY][0-9][ABCEGHJ-NPRSTV-Z][ ]?[0-9][ABCEGHJ-NPRSTV-Z][0-9]$/i; // true if good
	if (postalCode == "") {
		postalCodeMessage.textContent = "Postal code can't be blank";
		postalCodeMessage.setAttribute("style","color:red;width:100%;");
		areErrors = true;
	} else if (postalCodeRegex.test(postalCode) == false) {
		postalCodeMessage.textContent = "Postal code is not a valid format; try something like V8V 8V8";
		postalCodeMessage.setAttribute("style","color:red;width:100%;");
		areErrors = true;
	} else {
		postalCodeMessage.textContent = "Good postal code";
		postalCodeMessage.setAttribute("style","color:green;width:100%;");
	}



	// phoneNumber: not blank, regex match
	let phoneNumberRegex = /^\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/; // true if good
	if (phoneNumber == "") {
		phoneMessage.textContent = "Phone number can't be blank";
		phoneMessage.setAttribute("style","color:red;width:100%;");
		areErrors = true;
	} else if (phoneNumberRegex.test(phoneNumber) == false) {
		phoneMessage.textContent = "Phone number is not a valid format; try something like 111-222-3333";
		phoneMessage.setAttribute("style","color:red;width:100%;");
		areErrors = true;
	} else {
		phoneMessage.textContent = "Good phone number";
		phoneMessage.setAttribute("style","color:green;width:100%;");
	}

	if (!areErrors) {
	
		let personFullname = document.getElementById("person-fullname");
		let personEmail = document.getElementById("person-email");
		let personAge = document.getElementById("person-age");
		let personPostalcode = document.getElementById("person-postalcode");
		let personPhone = document.getElementById("person-phone");
	
		personFullname.textContent = firstName.toUpperCase() + " " + lastName.toUpperCase();
		personEmail.textContent = email;
		personAge.textContent = age;
		personPhone.textContent = phoneNumber;
		personPostalcode.textContent = postalCode;

  
		personCard.setAttribute("style","display:flex;width:18rem;");
		logoutItem.setAttribute("style","display:list-item");
		loginItem.setAttribute("style","display:none");
	
		greetingMessage.textContent = "Hello " + firstName.toUpperCase() + " " + lastName.toUpperCase();
	
		greetingMessage.setAttribute("style","display:list-item");
	
	}
  
  return false;
}