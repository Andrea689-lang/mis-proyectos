/* Exercise 1.1 -- Using Javascript Functions */ 


let spacesOutput = document.getElementById("spaces-output");
let lettersOutput = document.getElementById("letters-output");
let spacesInput = document.getElementById("spaces-input");
let lettersInput = document.getElementById("letters-input");
let theLetter = document.getElementById("the-letter");

let checkspacesButton = document.getElementById("checkspaces-button");
 checkspacesButton.onclick = function () { 
	let spacesText = spacesInput.value;
	console.log(spacesText);
	let countSpaces = howManySpaces(spacesText);
	console.log(countSpaces);
	spacesOutput.textContent = countSpaces;
 }
 
 
let checklettersButton = document.getElementById("checkletters-button");
 checklettersButton.onclick = function () {
	 let spacesText = spacesInput.value;
	 let lettersText = lettersInput.value;
	 console.log(lettersText);
	 let countLetters = howManyFound(spacesText, lettersText);
	 console.log(countLetters);
	 lettersOutput.textContent = countLetters;
	 theLetter.textContent = lettersText;
}


function howManySpaces(input) {
	return howManyFound(input, " ");
}

function howManyFound(input, whatToLookFor) {

	let numberFound = 0;
	for (let i = 0; i < input.length; i++) {
		let thisChar = input.charAt(i);
		if (thisChar == whatToLookFor) {
			numberFound++;
		}
	}
	return numberFound;
}

/* Exercise 1.2 - dates */

let dateInput = document.getElementById("date-input");
let wageInput = document.getElementById("wage-input");
let wageButton = document.getElementById("wage-button");


let dateOutput = document.getElementById("date-output");
let daysOutput = document.getElementById("days-output");
let workdaysOutput = document.getElementById("workdays-output");
let wageOutput = document.getElementById("wage-output");
let salaryOutput = document.getElementById("salary-output");
				
				
wageButton.onclick = function () {
	
		 let dateText = dateInput.value;
		 let wageText = wageInput.value;
		 console.log(dateText);
		 console.log(wageText);
		
		 let inputDate = getDateFromText(dateText);
		 
		 let year = inputDate.getFullYear();
		 let month = inputDate.getMonth();
		 
		 let numberOfDays = daysInMonth(year, month);
		 console.log(numberOfDays);
		 
		 let weekdays = getWeekdays(year, month, numberOfDays);
		 console.log(weekdays);
		 
		 let wages = parseFloat(wageText);
		 console.log(wages);
		 
		 let totalWages = wages * weekdays * 8;
		 console.log(totalWages);
		 
		 dateOutput.textContent = dateText;
		 daysOutput.textContent = numberOfDays;
		 workdaysOutput.textContent = weekdays;
		 wageOutput.textContent = wages;
		 salaryOutput.textContent = "$" + totalWages.toFixed(2);
	
}

function getDateFromText(dateText) {
	
		// to deal with timezone issues
		// treat every date as if it was in GMT 0 (i.e. near London)
		 let inputDate = new Date(new Date(dateText).toLocaleString("en-US",{timeZone:"Europe/London"}));
		 return inputDate;
}

function getWeekdays(year, month, days) {
	
	let weekdays = 0;
	for (let i=1; i<=days; i++) {
    // what day of the week? if it is 1 to 5, it is a weekday
		let monthDate = new Date(year,month,i);
		console.log(monthDate);
		let dayOfWeek = monthDate.getDay(); // 0 for Sunday, 6 for Saturday
		console.log(i + " " + dayOfWeek);
		if (dayOfWeek >= 1 && dayOfWeek <= 5) {
			weekdays++;
		}
	}
	return weekdays;
}
function daysInMonth(year,month) {
	// add one to go the next month, 4 is May, so 5 is June
	month++;
	// first date in the next month is 1, subtract 1 = the 0 date, i.e., the last date of the previous month
	// June 1st minus 1 is June 0 = May 31
    return new Date(year,month,0).getDate();
}

/* Part 2: error handling */
let numberInput = document.getElementById("number-input");
let numberOutput = document.getElementById("number-output");
let numberMessage = document.getElementById("number-message");
let numberOutcome = document.getElementById("number-outcome");
let numberButton = document.getElementById("number-button");

numberButton.onclick = function () {
	
	let number = parseInt(numberInput.value);
	numberOutput.innerHTML = "<span style='color:black'>Your number is: " + number + "</span>";
	try {
		let answer = isItInRange(number);
		numberMessage.innerHTML = "<span style='color:black'>Your number value is greater than 2: <span style='color:blue'>" + number + "</span></span>";
		numberOutcome.innerHTML = "<span style='color:red'>" + answer + "</span>";
	} catch (error) {
		numberMessage.innerHTML = "<span style='color:black'>Your number value is less than 2: <span style='color:blue'>" + number + "</span></span>";
		numberOutcome.innerHTML = "<span style='color:red'>" + error + "</span>";

	}


}


function isItInRange(input) {

	if (input <= 0) {
    	throw new Error("Your number " + input + " must be Greater than Zero"); 
	}
	if (input < 2) {
		throw new Error("Your number " + input + " is less than 2");
	}
   	return "Your number is in the correct range";

}

