/*
handler for the weather widget
goes into #weather-holder
*/
const api1 = "552ede3c087c5810a2bbbf22dfea5b8c";
const api2 = "13fbb2fcacaf75142525186c4d3e8546";
const api3 = "408910547897fd9d7029410128827a6d";
const apiURLBase = "https://api.openweathermap.org/data/2.5/weather?lat=10.39972&lon=-75.51444&units=metric&appid=";

let apiURL = apiURLBase + api1;

const iconURLBase = "https://openweathermap.org/img/wn/";
const iconURLSuffix = "@2x.png";

/*
				<div id="current-weather-temperature"></div>
				<div id="current-weather-icon"></div>

				<div id="current-weather-conditions"></div>
				*/
$(document).ready(function() {
	// load the weather
	/*
	{
		"coord":{"lon":-75.5144,"lat":10.3997},
		"weather":[{"id":800,"main":"Clear","description":"clear sky","icon":"01d"}],
		"base":"stations",
		"main":{"temp":31.65,"feels_like":36.56,"temp_min":31.65,"temp_max":31.65,"pressure":1008,"humidity":61,"sea_level":1008,"grnd_level":1004},
		"visibility":10000,
		"wind":{"speed":1.49,"deg":261,"gust":2.13},
		"clouds":{"all":1},"dt":1689955690,
		"sys":{"country":"CO","sunrise":1689936535,"sunset":1689982057},"timezone":-18000,"id":3687238,"name":"Cartagena","cod":200}
	*/
	
	
	$.getJSON( apiURL, function( data ) {

		// data is a JSON Object
		let conditions = data.weather[0].main;
		let iconID = data.weather[0].icon;
		let temperature = data.main.temp;
		
		console.log(conditions);
		console.log(iconID);
		console.log(temperature);
		
		let iconURL = iconURLBase + iconID + iconURLSuffix;
		
		$("#current-weather-temperature").text(temperature + "c");
		$("#current-weather-conditions").text(conditions);
		
		$("#current-weather-icon").append("<img style='max-width:70px;height:auto' />");
		$("#current-weather-icon img").attr("src",iconURL);

 

	});
});