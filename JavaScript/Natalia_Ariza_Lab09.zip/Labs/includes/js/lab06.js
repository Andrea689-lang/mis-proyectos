// Creating a Hotel class using ES6



class Hotel {
  constructor(name, city, rooms, booked, gym) {
	  
    this.name = name;
    this.city = city;
    this.rooms = rooms;
    this.booked = booked;
    this.gym = gym;
	
	this.restaurants = [["Donde La Arepa", "Colombian"], ["Casa Ramen", "Japanese"], ["Pizza Hermosa", "Italians"]];

	this.roomTypes = ["Twin","Double","Suite"];
	this.location = "Vancouver";
	this.swimmingPool = true;
	this.airportShuttle = false;
  
    }
	
	getName() {
		return this.name;
	}
	setName(name) {
		this.name = name;
	}
	
	getCity() {
		return this.city;
	}
	setCity(city) {
		this.city = city;
	}
	
	getRooms() {
		return this.rooms;
	}
	setRooms(rooms) {
		this.rooms = rooms;
	}
	
	getBooked() {
		return this.booked;
	}
	setBooked(booked) {
		this.booked = booked;
	}
	
	getGym() {
		return this.gym;
	}
	setGym(gym) {
		this.gym = gym;
	}
		
	
	
	bookRoom() {
		if (this.booked < this.rooms) {
			this.booked++; // only increment if there are still rooms to book
		}
		return "Room Booked. There are " + this.booked + " / " + this.rooms + " booked.";
	}
	cancelRoom() {
		if (this.booked>0) {
			this.booked--; // only decrement if there are booked rooms
		}
		return "Room Canceled. There are " + this.booked + " / " + this.rooms + " booked.";
	}

  }

class Resort extends Hotel {
	constructor(name, city, rooms, booked, gym, resortType, beachFront, kidsClub) {
		super(name,city,rooms,booked,gym);
		this.resortType = resortType;
		this.beachFront = beachFront;
		this.kidsClub = kidsClub;
		
	}
	getResortType() {
		return this.resortType;
	}
	setResortType(resortType) {
		this.resortType = resortType;
	}
	
	getBeachFront() {
		return this.beachFront;
	}
	setBeachFront(beachFront) {
		this.beachFront = beachFront;
	}
	
	getKidsClub() {
		return this.kidsClub;
	}
	setKidsClub(kidsClub) {
		this.kidsClub = kidsClub;
	}

}
  
/*
What follows is javascript that uses our Hotel and Resort classes
*/
	
	let hotel = new Hotel("Vancouver Special","Vancouver",12,0,true); // start off with no rooms booked
	
	displayHotelInfo();
	
	function displayHotelInfo() {
		document.getElementById("hotel-name").textContent = hotel.getName();
		document.getElementById("hotel-city").textContent = hotel.getCity();
		
	
		let roomTypes = hotel.roomTypes;
		let roomTypesOutput = "";
		for (let i=0; i<roomTypes.length; i++) {
			roomTypesOutput += roomTypes[i];
			// if we're not on the last item
			if (i<roomTypes.length-1) {
				roomTypesOutput += ", ";
			}
		}
		document.getElementById("hotel-roomTypes").textContent = roomTypesOutput;
		
		
		// Boolean, the hotel has a shuttle
		  let hasShuttle = hotel.swimmingPool; // Set to true if the hotel has a shuttle, or false if it doesn't
		  let shuttleCheck = document.getElementById("shuttle-check");
		  shuttleCheck.textContent = hasShuttle;
		
		// Boolean, the hotel has a pool
		  let hasPool = hotel.airportShuttle; // Set to true if the hotel has a pool, or false if it doesn't
		  let poolCheck = document.getElementById("pool-check");
		  poolCheck.textContent = hasPool;
		 
		
		document.getElementById("hotel-restaurant-count").textContent = hotel.restaurants.length;
		let restaurantList = document.getElementById("hotel-restaurants");
		let restaurantOutput = "";
		for (let [key, value] of hotel.restaurants) {
			restaurantOutput += "<li><strong>" + key + "</strong> / Type / <strong>" + value + "</strong></li>";
		}
		restaurantList.innerHTML = restaurantOutput;
		
	}

	document.getElementById("hotel-book-button").addEventListener("click",function() {
		let output = hotel.bookRoom();
		document.getElementById("hotel-message").textContent = output;
	});
	document.getElementById("hotel-cancel-button").addEventListener("click",function() {
		let output = hotel.cancelRoom();
		document.getElementById("hotel-message").textContent = output;
	});
	document.getElementById("hotel-resort-button").addEventListener("click",function() {
		document.getElementById("resort-holder").setAttribute("style","display:block");
	});
	
	
	
	let resort = new Resort("Victoria Resort","Victoria",12,0,true,"Family",true,false); // start off with no rooms booked
	displayResortInfo();
	
	function displayResortInfo() {
		document.getElementById("resort-name").textContent = resort.getName();
		document.getElementById("resort-city").textContent = resort.getCity();
		document.getElementById("resort-type").textContent = resort.getResortType();
	    document.getElementById("beach-front").textContent = resort.getBeachFront();
		document.getElementById("kids-club").textContent = resort.getKidsClub();

	
	}

	document.getElementById("resort-book-button").addEventListener("click",function() {
		let output = resort.bookRoom();
		document.getElementById("resort-message").textContent = output;
	});
	document.getElementById("resort-cancel-button").addEventListener("click",function() {
		let output = resort.cancelRoom();
		document.getElementById("resort-message").textContent = output;
	});



