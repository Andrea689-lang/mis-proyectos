// jquery for the document Object
// jquery event for when the object is ready

$(document).ready(function() {
	
	// jquery in here is for attaching listeners to objects
	
	
	// this function is the action to taken when the event happens
	// jq selector the .quiz-hint class
	// jq event for when the object is hovered over
	$(".quiz-hint").hover(  // (in quotes) selectors are almost identical to how you use them in CSS
		// two actions: hover triggers and hover ends
		function() { // hover in
			// jq selector for .quiz-hint-value WITHIN "this", which is the parent object that we're acting on
			let quizHintValue = $(".quiz-hint-value",this);
			// trigger the fadeIn event
			$(quizHintValue).fadeIn();
		},
		function() { // hover out
			let quizHintValue = $(".quiz-hint-value",this);
			$(quizHintValue).fadeOut();
		}		
	);
	
	
});

// "variable scope" -- sort of like "global" variables, in that we want to keep track of their values in multiple functions
let clockDisplay = ""; // we'll use the value of the clock in both the clock timer and after they submit the quiz
let clockValue = 0.00;
let clockTimer; // a timer object we'll be starting and later stopping
let inputNameValue;

//!------------------------------------------------------------------------------------->
document.getElementById("quiz-entry-form").addEventListener("submit",function(event) {

	console.log("handleQuizEntryFormSubmit");
	event.preventDefault();

	
	let nameHelp = document.getElementById("name-help");
	let inputName = document.getElementById("input-name");
	let quizEntry = document.getElementById("quiz-entry");
	let quizMain = document.getElementById("quiz-main-form");
	
	inputNameValue = inputName.value.trim();
	
	if (inputNameValue == "") {
		nameHelp.setAttribute("style","display:block");
	} else {
		nameHelp.setAttribute("style","display:none");
		quizEntry.setAttribute("style","display:none");
		
		$("#quiz-main-form").fadeIn();
		
		//Get placeholder element
		let welcomeElement = document.getElementById("welcome");

		welcomeElement.textContent = "Welcome, " + inputNameValue + "! Good Luck!";
		
		// trigger the clock
		clockTimer = setInterval(function() {
			clockValue += 0.01;
			// convert 999.99 into 999:99
			let seconds = Math.trunc(clockValue); // 999.99 -> 999
			let centiSeconds = Math.trunc(100 * (clockValue - seconds)); // (999.99 - 999) = .99   100 * .99 = 99.00001   99.00001 -> 99
			clockDisplay = seconds + ":" + centiSeconds;
			// change the clock text using jquery
			$("#clock").text(clockDisplay);
					
		},10); // every 10 milliseconds, i.e. 1/100 of a second
	}
	
});
document.getElementById("quiz-main-form").addEventListener("submit",function(event) {

	console.log("handleQuizMainFormSubmit");
	event.preventDefault();
	


	// for each of the quiz questions, figure out if they got the right answer
	let correct = 0; // the total number of correct answers
	let total = 5; // the total number of questions
	
	if (isRadioAnswerCorrect("quiz-1-input","b")) {
		console.log("#1 correct");
		correct++;
	}
	// 2 3 and 4!!!!!
	if (isRadioAnswerCorrect("quiz-2-input","b")) {
		console.log("#2 correct");
		correct++;
	}	
	if (isRadioAnswerCorrect("quiz-3-input","c")) {
		console.log("#3 correct");
		correct++;
	}	
	if (isRadioAnswerCorrect("quiz-4-input","a")) {
		console.log("#4 correct");
		correct++;
	}	
		
	
	// let's make sure their checkbox usage was valid before we check if it's correct
	if (!validCheckbox("quiz-5-input",2)) {
		document.getElementById("quiz-question-5-message").setAttribute("style","display:block");
		return;
	} else {
		document.getElementById("quiz-question-5-message").setAttribute("style","display:none");
		if (isCheckboxAnswerCorrect("quiz-5-input",["a","b"])) {
			console.log("#5 correct");
			correct++;
		}
	}
	
	// stop the clock
	clearInterval(clockTimer);
	
	// after all the questions have been validated, show the message about how well then did
	
	// use jQuery to fill in the score and show it
	
	$("#score-correct").text(correct); // if no parameter is given .text() will return the text... with a parameter, we're setting the text. Others: val() val("this value") attr("href")  attr("href","https...")
	$("#score-total").text(total);
	$("#score").fadeIn(3000); // or show() and hide() -- this is really just display:block and display:none -- more modern jquery uses fadeIn() and fadeOut() -- start with css "display:none" and then use jquery to show it
	
	
	/*
	#results
		#results-score-normal / -perfect
			#results-name
			#results-correct
			#results-total
		#results-time
			#results-time-value
	*/
	$("#results-time-value").text(clockDisplay);
	$(".results-name").text(inputNameValue);
	$(".results-correct").text(correct);
	$(".results-total").text(total);
	
	$("#results").modal("show"); // show the bootstrap modal

	
	if (total==correct) {
		$('#results-score-perfect').show();
		// call the flash with an initial count of 9 (hide/show 9 times)
		flash(9);
	} else {
		$("#results-score-normal").show();
	}
	
	
	
});

//https://stackoverflow.com/questions/51654516/jquery-make-element-flash-repeatedly
// hide it, show it over a small period of time, and then iteratively call flash with a lowered number
function flash(n) {
  console.log(n);
  
  if (n > 0) {
    $('#results-score-perfect').css('opacity', '0'); // hide it
    
    $('#results-score-perfect').animate({'opacity': '1'}, 400, function() { //set the opacity over a period of 0.4 of a second, and then call flash
      flash(n - 1);
    });
  }
}






function validCheckbox(checkboxInputName,numberOfAnswers) {
	
	const checkBoxes = document.querySelectorAll("input[name='" + checkboxInputName + "']");
	let totalSelected = 0;
	for (const checkBox of checkBoxes) {
		if (checkBox.checked) {
			totalSelected++;
		}
	}
	// how many do we need correct?
	if (totalSelected == numberOfAnswers) {
		return true;
	} else {
		return false;
	}
}


function isCheckboxAnswerCorrect(checkboxInputName,correctAnswers) {
	
	const checkBoxes = document.querySelectorAll("input[name='" + checkboxInputName + "']");
	let totalCorrect = 0;
	for (const checkBox of checkBoxes) {
		if (checkBox.checked) {
			selectedAnswer = checkBox.value;
			// is the selectedAnswer in the list of correctAnswers?
			if (correctAnswers.includes(selectedAnswer)) {
				totalCorrect++;
			}
		}
	}
	// how many do we need correct?
	if (totalCorrect == correctAnswers.length) {
		return true;
	} else {
		return false;
	}
}



function isRadioAnswerCorrect(radioInputName,correctAnswer) {
	
	const radioButtons = document.querySelectorAll("input[name='" + radioInputName + "']");
	let selectedAnswer = "";
	for (const radioButton of radioButtons) {
		if (radioButton.checked) {
			selectedAnswer = radioButton.value;
			break;
		}
	}
	if (selectedAnswer == correctAnswer) {
		return true;
	} else {
		return false;
	}
	
}