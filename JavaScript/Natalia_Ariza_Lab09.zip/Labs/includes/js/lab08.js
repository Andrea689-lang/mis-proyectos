
  $( function() {
	  
	  /*
	  jQuery selectors:
	  - name of the jQuery object, such as document or window or thisObject   ... let thisObject = jQuery("selector");
	  - same as CSS selectors
		- ("input") ... all input tags
		- ("#thisid") ... the tag with an id of "thisid"
		- (".thisclass")
		- ("input[name='room-selection']") ... by attribute, where the attribute called "name" matches "room-selection"
		- ("input[name='room-selection'][type='radio']") ... more than one matching attribute
		- ("#thisid a[href='http...']") ... this is a parent / child... all <a href='http...'> within the #thisid div
		- ("#thisid, #thatid") ... matching either thisid or thatid
	  
	  
	  */
	  
	  // all input tags with a name of "room-selection"
    $( "input[name='room-selection']" ).checkboxradio({
      icon: false
    });
	$( "#rooms" ).controlgroup();
	// arrival date no sooner than tomorrow
	$( "#arrival-date").datepicker({ minDate: "+1D"});
	// departure date no sooner than 2 days from now
	$( "#departure-date").datepicker({ minDate: "+2D"});
	

	// $("#dialog").dialog({autoOpen:false});
	
  } );
  
  let numberOfRooms = 5;
  let numberBooked = 0;
  let totalRate = 0.00;
  let nightlyRate = 0.00;
  
  //document.getElementById("booking-form").addEventListener("submit",function(event) {
  document.getElementById("book-button").addEventListener("click",function(event) {

	console.log("handle booking form submit");
	event.preventDefault();
	
	let isOK = true;
	
	$("#dates-error").hide(); // although display:none is the default for this element, if they're submitting a 2nd time (after an error), we want to start by hiding the errors
	$("#rooms-error").hide(); // although display:none is the default for this element, if they're submitting a 2nd time (after an error), we want to start by hiding the errors
	
	let arrivalDateInput = document.getElementById("arrival-date").value;
	let departureDateInput = document.getElementById("departure-date").value;
	
	/*
	rules for the dates:
	- make sure both dates have values
	- make sure arrivalDate is later or equal to today
	- make sure departureDate is later than arrivalDate
	*/
	let arrivalDate, departureDate;
	if( 
		arrivalDateInput == "" ||
		departureDateInput == ""
	) {
		isOK = false;
		$("#dates-error-message").text("You need to select a date for both Arrival and Departure.");
		$("#dates-error").show();
	} else {
		console.log("arrivalDateInput " + arrivalDateInput);
		console.log("departureDateInput " + departureDateInput);
		// evaluate if the dates are in the right range
		arrivalDate = new Date(arrivalDateInput);
		departureDate = new Date(departureDateInput);
		console.log("arrivalDate " + arrivalDate);
		console.log("departureDate " + departureDate);


		if (departureDate <= arrivalDate) {
			console.log("departure error");
			isOK = false;
			$("#dates-error-message").text("Your Departure Date is too soon.");
			$("#dates-error").show();
		}

	}

	const radioButtons = document.querySelectorAll("input[name='room-selection']");
	let selectedRoom = "";
	for (const radioButton of radioButtons) {
		if (radioButton.checked) {
			selectedRoom = radioButton.value;
			break;
		}
	}
	// if the room is blank, show them an error and set isOK to false
	if (selectedRoom == "") {
		isOK = false;
		$("#rooms-error-message").text("You need to select a room type.");
		$("#rooms-error").show();
		
		
		// $("#dialog").dialog("open");
	}
	
	/*
	#dates-error
	#dates-error-message
	#rooms-error
	#rooms-error-message	
	*/
	
	if (isOK) {
		// book the room
		// 1) figure out how many nights
		
		// number of days between arrivalDate and departureDate
		const timeDiff = departureDate.getTime() - arrivalDate.getTime(); // in milliseconds
		const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
		console.log(timeDiff);
		console.log(daysDiff);
		
		let numberOfNights = daysDiff;
		
		
		// 2) figure out nightly rate
		
		 nightlyRate = 0.00;
		
		switch (selectedRoom) {
			case "standard":
				nightlyRate = 150.00;
				break;
			case "double":
				nightlyRate = 200.00;
				break;
			case "penthouse":
				nightlyRate = 350.00;
				break;
		}
		
		 totalRate = numberOfNights * nightlyRate;
		console.log(totalRate);
		
		numberBooked++;
		
		let numberBookedMessage = "Room booked, there are " + numberBooked + " / " + numberOfRooms + " booked";
		document.getElementById("rooms-booked-message").textContent = numberBookedMessage;
		
		document.getElementById("days-output").textContent = numberOfNights;
		document.getElementById("rate-output").textContent = "$" + nightlyRate;

		document.getElementById("total-output").textContent = "$" + totalRate;
		
		$("#cancel-button").attr("disabled",false);
		
		$("#room-booked-modal").modal('show');



		

		
	}
	
	
  });
  
  document.getElementById("cancel-button").addEventListener("click",function(event) {

	event.preventDefault();
	
		numberBooked--;
		
		let numberBookedMessage = "Room canceled, there are " + numberBooked + " / " + numberOfRooms + " booked";
		document.getElementById("rooms-canceled-message").textContent = numberBookedMessage;
		
		document.getElementById("rate-canceled-output").textContent = "$" + nightlyRate;

		document.getElementById("total-canceled-output").textContent = "$" + totalRate;
		
		$("#cancel-button").attr("disabled",true);
		
		$("#room-canceled-modal").modal('show');
	
});