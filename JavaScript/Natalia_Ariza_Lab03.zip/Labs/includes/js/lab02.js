//3 Prices for rooms?

 alert ("Enter three prices!");
 
//Get placeholder element
let threePricesElement = document.getElementById("threePrices");
let middleNumberElement = document.getElementById("middleNumber");
let medianNumberElement = document.getElementById("medianNumber");
//Prompt the user for three numbers
let number1 = prompt("Enter the first number:");
let number2 = prompt("Enter the second number:");
let number3 = prompt("Enter the third number:");

number1Value = parseInt(number1);
number2Value = parseInt(number2);
number3Value = parseInt(number3);

threePricesElement.textContent = "$" + number1Value + ", $" + number2Value + ", $" + number3Value;

let calcButton = document.getElementById("calculate-button");
 calcButton.onclick = function () {
		console.log("This is the DOM Event handler");
		
		//Calculate middle number
		let numbers = [number1Value,number2Value,number3Value];
		console.log(numbers);
		
		/*
		Sorting an array numerically
		https://www.w3schools.com/jsref/jsref_sort.asp#:~:text=Sort%20numbers%20in%20ascending%20order%3A
		if a < b ... negative number
		if a == b ... 0
		*/
		numbers.sort(function(a, b){return a-b})
		let middleNumber = numbers[1];
		// Displaying the middle number
		let numberColorHTML = "";
		if (middleNumber % 2 == 0) {
			numberColorHTML = "color:red";
		}
		middleNumberElement.innerHTML = "<span style='" + numberColorHTML + "'>" + "$" + middleNumber + "</span>";

		//Calculate mean value
		let mean = (number1Value + number2Value + number3Value) / 3;
		
		// fixed to 2 decimal places
		// https://www.w3schools.com/js/js_number_methods.asp#:~:text=The%20toFixed()%20Method
		medianNumberElement.textContent = "$" + mean.toFixed(2);

	}

//Display How Full the Hotel is

let occupancyButton = document.getElementById("occupancy-button");
 occupancyButton.onclick = function () {
	 let inputOccupancy = document.getElementById("occupancy-input").value;
	 let inputOccupancyValue = parseInt(inputOccupancy);
	 if (inputOccupancyValue < 0 || inputOccupancyValue > 100) {
		 alert("Incorrect - not between 0-100");
		 return;
	 }
	 
	 /*
	 A - 90-100 - Green
	 B - 80-89 - Blue
	 C - 65-79 - Yellow
	 D - 51-64 - Black
	 F - 0-50 - Red
	*/
	let occupancyRating = "";
	if (inputOccupancyValue >= 90) {
		occupancyRating = "A";
	} else if (inputOccupancyValue >= 80) {
		occupancyRating = "B";
	} else if (inputOccupancyValue >= 65) {
		occupancyRating = "C";
	} else if (inputOccupancyValue >= 51) {
		occupancyRating = "D";
	} else {
		occupancyRating = "F";
	}
	
	let occupancyColor = "";
	switch (occupancyRating) {
		case "A":
			occupancyColor = "green";
			break;
		case "B":
			occupancyColor = "blue";
			break;
		case "C":
			occupancyColor = "yellow";
			break;
		case "D":
			occupancyColor = "black";
			break;
		default:
			occupancyColor = "red";
	}
	
	document.getElementById("booked").innerHTML = "<span style='color:" + occupancyColor + "'>" + inputOccupancyValue + "%</span> booked!";
 }
 
//Iteration

 let iterationButton = document.getElementById("iteration-button");
 iterationButton.onclick = function () {
	 let inputIteration = document.getElementById("iteration-input").value;
	 let inputIterationValue = parseInt(inputIteration);
	 if (inputIterationValue < 2 || inputIterationValue > 9) {
		 alert("Incorrect - not between 2 and 9");
		 return;
	 }
	 let output = "";
	 // 5? 1 to 5 and then 4 to 1
	 for (let i=1; i<=inputIterationValue; i++) {
		 for (let j=1; j<=i; j++) {
			 output += inputIterationValue;
		 }
		 output += "<br />";
	 }
	 for (let i=inputIterationValue-1; i>=1; i--) {
		 for (let j=1; j<=i; j++) {
			 output += inputIterationValue;
		 }
		 output += "<br />";
	 }
	 document.getElementById("iteration-output").innerHTML = output;
	 
 }
 
//Who gets there the fastest?

let speedButton = document.getElementById("speed-button");
 speedButton.onclick = function () {
	
	let Alexa = parseInt(document.getElementById('alexa-input').value)
	let Siri = parseInt(document.getElementById('siri-input').value)
	let winner = "";
	
	document.getElementById("alexa-output").innerHTML = Alexa;
	document.getElementById("siri-output").innerHTML = Siri;
	
	if(parseInt(Alexa) < parseInt(Siri) ){
		document.getElementById("alexa-output").style="color:blue";
		document.getElementById("siri-output").style="color:red";
		winner = "Siri";
	}
	
	else {
		document.getElementById("alexa-output").style="color:red";
		document.getElementById("siri-output").style="color:blue";
		winner = "Alexa";
	}
	
	document.getElementById("winner").innerHTML = winner;
	document.getElementById("winner").style="color:red";
	}

 
