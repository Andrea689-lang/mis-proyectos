//Task 1

// Array of hotel room objects
let hotelRooms = [
  {
	img: "includes/images/standardtype.jpg",
    // Picture by <a href="https://unsplash.com/@neonbrand?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText">Kenny Eliason</a> on <a href="https://unsplash.com/photos/iAftdIcgpFc?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText">Unsplash</a>
	type: "Standard",
    price: "$159", 
    description: "Single room with a bed",
	options:[]
  },
  
  {
	img: "includes/images/double.jpg",
	// Picture by <a href="https://unsplash.com/es/@frugalflyer?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText">Frugal Flyer</a> on <a href="https://unsplash.com/photos/mo3FN80PATM?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText">Unsplash</a>
    type: "Double",
    price: "$229",
    description: "Double room with a bed",
	options:[]
  },
  
  {
	img: "includes/images/penthousetype.jpg",
	// Picture by <a href="https://unsplash.com/@mostafasafadel?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText">Mostafa Safadel</a> on <a href="https://unsplash.com/photos/cHjAxnJk_wQ?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText">Unsplash</a>
    type: "Penthouse",
    price: "$359",
    description: "King Size Bed",
	options: ["Bar", "Jacuzzi"]

  }
];

// Display the results using a loop
window.onload = function() {
  let hotelTable = document.getElementById("hotelTable");
  
  for (let i = 0; i < hotelRooms.length; i++) {
		let row = hotelTable.insertRow(i);
		
		let cell1 = row.insertCell(0);
		let cell2 = row.insertCell(1);
		
		cell1.setAttribute("class","hotel-image-cell p-3");
		cell1.setAttribute("style","width:50%;");
		cell2.setAttribute("class","hotel-details-cell p-3");
		cell2.setAttribute("style","width:50%;");

		
		let imgNode = document.createElement("img");
		imgNode.setAttribute("src", hotelRooms[i].img);
		imgNode.setAttribute("class","hotel-image");
		imgNode.setAttribute("style","max-width:100%;height:auto;");
		cell1.appendChild(imgNode);
		
		let typeNode = document.createElement("div");
		typeNode.setAttribute("class","room-type my-1");
		typeNode.setAttribute("style","font-weight:bold;");

		typeNode.textContent = hotelRooms[i].type;
		
		let priceNode = document.createElement("div");
		priceNode.setAttribute("class","room-price my-1");
		priceNode.setAttribute("style","font-weight:bold;");
		priceNode.textContent = hotelRooms[i].price;
 
		let descriptionNode = document.createElement("div");
		descriptionNode.setAttribute("class","room-description my-1");
		descriptionNode.textContent = hotelRooms[i].description;
 
		let options = hotelRooms[i].options;
		if (options.length > 0) {
			let optionsNode = document.createElement("ul");
			optionsNode.setAttribute("class","options-list");
			optionsNode.setAttribute("style","list-style:none;padding:0;margin:0;");
			for (let j=0; j<options.length; j++) {
				let optionNode = document.createElement("li");
				optionNode.setAttribute("style","margin:0;");
				optionNode.textContent = options[j];
				optionsNode.appendChild(optionNode);
			}
			descriptionNode.appendChild(optionsNode);
		}
 
 
		let buttonNode = document.createElement("a");
		buttonNode.setAttribute("href","#");
		buttonNode.setAttribute("class","hotel-button btn btn-success");
		buttonNode.textContent = "Book Room";
		
		buttonNode.addEventListener("click",function(thisPrice) {
			return function() {
				alert("Your room is " + thisPrice + " per night");
			}
		} (hotelRooms[i].price));
		
		let buttonOuterNode = document.createElement("div");
		buttonOuterNode.setAttribute("class","button-outer my-1");
		buttonOuterNode.setAttribute("style","text-align:right;");
		buttonOuterNode.appendChild(buttonNode);
		
		cell2.appendChild(typeNode);
		cell2.appendChild(priceNode);
		cell2.appendChild(descriptionNode);
		cell2.appendChild(buttonOuterNode);
		    

	}



//Task 2

		let sampleTable = document.getElementById("sampleTable");
		let rowButtonNode = document.getElementById("myButton");
		let counter = 1;
		rowButtonNode.addEventListener("click",function() {
			counter++;
			let row = sampleTable.insertRow();
		
			let cell1 = row.insertCell(0);
			let cell2 = row.insertCell(1);	
			cell1.textContent = "Row" + counter + " cell1";
			cell2.textContent = "Row" + counter + " cell2";
		});

}